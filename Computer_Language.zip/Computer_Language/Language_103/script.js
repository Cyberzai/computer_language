let decimalNumber = 0;
let userBinary = [];
let level = 1;
let wrongAttempts = 0;
const maxAttempts = 3;
const totalLevels = 10;
const baseRange = 16;
let timer;
let timeLeft = 20;

function generateQuestion() {
    if (level <= totalLevels) {
        decimalNumber = Math.floor(Math.random() * Math.min(baseRange * Math.pow(2, level - 1), 128));
        document.getElementById('question').innerText = `Convert ${decimalNumber} to binary:`;
        document.getElementById('level').innerText = `Level: ${level}`;
        userBinary = [];
        document.getElementById('user-answer').innerText = '';
        document.getElementById('result').innerText = '';
        document.getElementById('congratulations').style.display = 'none';
        timeLeft = 20;
        document.getElementById('timer').innerText = `Time left: ${timeLeft}s`;
        clearInterval(timer);
        timer = setInterval(updateTimer, 1000);
    } else {
        document.getElementById('game').style.display = 'none';
        document.getElementById('congratulations').style.display = 'block';
    }
}

function addBit(bit) {
    userBinary.push(bit);
    document.getElementById('user-answer').innerText = userBinary.join('');
}

function checkAnswer() {
    const userBinaryString = userBinary.join('');
    const userDecimal = parseInt(userBinaryString, 2);

    if (userDecimal === decimalNumber) {
        document.getElementById('result').innerText = 'Correct! Moving to next level...';
        level++;
        wrongAttempts = 0; // reset wrong attempts
        clearInterval(timer);
        setTimeout(generateQuestion, 1000);
    } else {
        wrongAttempts++;
        if (wrongAttempts >= maxAttempts) {
            document.getElementById('result').innerText = 'Incorrect. Starting from level 1...';
            level = 1;
            wrongAttempts = 0;
            clearInterval(timer);
            setTimeout(generateQuestion, 1000);
        } else {
            document.getElementById('result').innerText = `Incorrect. You have ${maxAttempts - wrongAttempts} attempts left.`;
        }
    }
}

function clearAnswer() {
    userBinary = [];
    document.getElementById('user-answer').innerText = '';
    document.getElementById('result').innerText = '';
}

function updateTimer() {
    timeLeft--;
    document.getElementById('timer').innerText = `Time left: ${timeLeft}s`;
    if (timeLeft <= 0) {
        clearInterval(timer);
        wrongAttempts++;
        if (wrongAttempts >= maxAttempts) {
            document.getElementById('result').innerText = 'Time up! Starting from level 1...';
            level = 1;
            wrongAttempts = 0;
        } else {
            document.getElementById('result').innerText = `Time up! You have ${maxAttempts - wrongAttempts} attempts left.`;
        }
        setTimeout(generateQuestion, 1000);
    }
}

window.onload = function() {
    generateQuestion();
    document.getElementById('background-music').play();
};
