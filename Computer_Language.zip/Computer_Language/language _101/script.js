let decimalNumber = 0;
let userBinary = [];
let level = 1;
const baseRange = 16;

function generateQuestion() {
    if (level <= 5) {
        decimalNumber = Math.floor(Math.random() * (baseRange * Math.pow(2, level - 1)));
        document.getElementById('question').innerText = `Convert ${decimalNumber} to binary:`;
        document.getElementById('level').innerText = `Level: ${level}`;
        userBinary = [];
        document.getElementById('user-answer').innerText = '';
        document.getElementById('result').innerText = '';
        document.getElementById('congratulations').style.display = 'none';
    } else {
        document.getElementById('game').style.display = 'none';
        document.getElementById('congratulations').style.display = 'block';
    }
}

function addBit(bit) {
    userBinary.push(bit);
    document.getElementById('user-answer').innerText = userBinary.join('');
}

function checkAnswer() {
    const userBinaryString = userBinary.join('');
    const userDecimal = parseInt(userBinaryString, 2);

    if (userDecimal === decimalNumber) {
        document.getElementById('result').innerText = 'Correct! Moving to next level...';
        level++;
        setTimeout(generateQuestion, 1000);
    } else {
        document.getElementById('result').innerText = 'Incorrect. Try Again!';
    }
}

function clearAnswer() {
    userBinary = [];
    document.getElementById('user-answer').innerText = '';
    document.getElementById('result').innerText = '';
}

window.onload = generateQuestion;
